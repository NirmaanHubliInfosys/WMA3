package exception;

public class AnException extends Throwable{

	int str1;

	AnException(int str2 ){
		str1=str2;
	}

//	@Override
//	public String toString() {
//		return "AnException [number1=" + number1 + "]";
//	}
	

}
