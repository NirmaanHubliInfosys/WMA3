package oops;

public class Parent {

		void eat()
		{
			System.out.println("parents...");
		} 
		
}  
		 


