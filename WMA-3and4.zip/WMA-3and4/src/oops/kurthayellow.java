package oops;



public interface kurthayellow{  
void print();  
void kurthasize();
}  
 
  
 
