package oops;

public interface kurthablue {
	void print(); 
	public void kurthasize();
}
