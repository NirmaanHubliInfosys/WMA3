package string;

public class StringNew {

	public static void main(String[] args) {
//		String s1="java";//string literal
//		char ch[]= {'s','t','r','i','n','g'};
//		String s2=new String(ch);//converting char array to string
//		String s3=new String("example");
//		System.out.println(s1);
//		System.out.println(s2);
//		System.out.println(s3);
		
		char[] ch1={'j','a','v','a'};
		System.out.println(ch1);
//		String s=new String(ch1);
	}

}
