package string;

public class A {

	static int m=100;//static variable
	
	void method() {
		int n=90;//local variable
	}
	public static void main(String[] args) {
		
int data=80;//instance variable
A a=new A();
System.out.println(m);
	}

}
