package string;

public class ExampleOfString1 {

	
	public static void main(String[] args) {
		char[]ch= {'j','a','v','a'};
		String s=new String(ch);
		System.out.println(s);
		
		String s1="welcome";
		String s2="Welcome";
		String s3="Welcome"//String constant pool
				
		int a=10;
		int b=10;
	}
}
