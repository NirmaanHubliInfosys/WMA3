package wma3;

public class Sample {

	public static void main(String[] args) {
		if(1>=2){
		  System.out.println("true");
		  }else {
			  System.out.println("false");
		  }
	}

}
