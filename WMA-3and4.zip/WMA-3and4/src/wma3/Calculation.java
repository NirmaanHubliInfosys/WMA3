package wma3;

public class Calculation {

	public static void main(String[] args) {
int sum=0;
for(int i=1;i<=3;i++) {
	sum=sum+i;
}
System.out.println("the sum of first 3 natural number is "+sum);
	}

}
