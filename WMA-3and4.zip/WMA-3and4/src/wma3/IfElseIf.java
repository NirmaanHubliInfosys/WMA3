package wma3;

public class IfElseIf {

	public static void main(String[] args) {
		int x=10;
		int y=20;
		if(x+y>50) {
			System.out.println("x+y is greater than 20");
		}else if(x+y<10){
			System.out.println("x+y is less than 59");
		}else {
			System.out.println("none of the above condition is not true");
		}

	}

}
