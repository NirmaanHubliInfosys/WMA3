package wma3;

public class Calculation1 {

	public static void main(String[] args) {
	int i=0;
	System.out.println("printing the list of first 10 even number");
	while(i<=10) {
		System.out.println(i);
		i=i+2;
	}
	}

}
