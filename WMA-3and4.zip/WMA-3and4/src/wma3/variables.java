package wma3;

public class variables {

	public static void main(String[] args) {
	

	}

}
