package wma3;

public class ForEach {

	public static void main(String[] args) {
		System.out.println("for each statements");
		int sum=0;
		int[] numbers= {0,1,2,3};
		for(int number:numbers) {
			System.out.println(number);
		}
		
	}

}
