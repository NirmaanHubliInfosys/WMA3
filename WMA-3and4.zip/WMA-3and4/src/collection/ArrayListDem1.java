package collection;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDem1 {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<>();
		al.add("nirmaan");
		al.add("it");
		al.add("java");
		al.add("training");

		System.out.println(al);
//		Iterator<String>iterator=al.iterator();
//		
//		while(iterator.hasNext()) {
//			String next=iterator.next();
//			System.out.println(next);
//		}

		
	}

}
