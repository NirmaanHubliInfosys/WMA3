package collection;

public class ArrayCollection {

	public static void main(String[] args) {
//		 int[] a=new int[5];//5-1=4
//		 
//		  a[0]=200;
//		  a[2]=300;
//		  a[3]=400;
//		  a[4]=500;
////		  a[5]=600;
//		  System.out.println(a[1]);
		
		
		int a[]=new int[5];
        a[0]=10;
        a[1]="Renuka"
        a[2]=10.00;
        
	}

}
